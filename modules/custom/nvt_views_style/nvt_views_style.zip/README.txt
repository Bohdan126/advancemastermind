BLOCK NaviTeamView Style
-----------
Project URL: http://www.thanhtuandev.com

=====
Installation
-----

1. Enable the module
2. Visit the Views page at Administration -> Structure -> Views
and a Block  and select NaviTeamView style.
3. Updating...